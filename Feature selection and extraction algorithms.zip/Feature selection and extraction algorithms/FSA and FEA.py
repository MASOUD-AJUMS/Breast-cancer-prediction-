import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import VarianceThreshold
from sklearn.feature_selection import f_classif, f_regression
from sklearn.feature_selection import SelectKBest, SelectPercentile
from sklearn import metrics
from sklearn.preprocessing import StandardScaler 
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.model_selection import KFold
#from sklearn.cross_validation import KFold
from sklearn.ensemble import BaggingClassifier
import sklearn
from sklearn.model_selection import cross_val_score
from sklearn.metrics import roc_auc_score
from matplotlib import pyplot
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import roc_curve, auc
from packaging.version import parse
from sklearn.model_selection import StratifiedKFold
from scipy import interp
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import BernoulliNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.feature_selection import VarianceThreshold, mutual_info_classif, mutual_info_regression
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import ExtraTreesClassifier 
from sklearn.feature_selection import RFE
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
import seaborn as sb
from sklearn.linear_model import Lasso
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn.multiclass import OneVsRestClassifier
from sklearn import svm, datasets
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import auc
from sklearn.metrics import plot_roc_curve
from sklearn.model_selection import StratifiedKFold
import matplotlib.patches as patches
from itertools import cycle
from sklearn.preprocessing import label_binarize
from sklearn.linear_model import RidgeClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler

from sklearn import datasets
from sklearn.linear_model import LogisticRegression
import numpy as np
import matplotlib.pyplot as plt
from mlxtend.plotting import plot_decision_regions
import pandas as pd
import seaborn as sns
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix,accuracy_score
from sklearn.metrics import classification_report
from sklearn import datasets
from sklearn.linear_model import LogisticRegression
import numpy as np
import matplotlib.pyplot as plt
from mlxtend.plotting import plot_decision_regions
import pandas as pd
import seaborn as sns
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import roc_curve, auc
from sklearn import datasets
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.preprocessing import label_binarize
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
from sklearn import svm, datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.metrics import roc_curve, auc
from sklearn.multiclass import OneVsRestClassifier
from sklearn.model_selection import cross_val_predict
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis as QDA
from itertools import cycle
from sklearn.ensemble import GradientBoostingClassifier
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import VarianceThreshold
from sklearn.feature_selection import f_classif, f_regression
from sklearn.feature_selection import SelectKBest, SelectPercentile
from sklearn import metrics
from sklearn.preprocessing import StandardScaler 
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.model_selection import KFold
#from sklearn.cross_validation import KFold
from sklearn.ensemble import BaggingClassifier
import sklearn
from sklearn.model_selection import cross_val_score
from sklearn.metrics import roc_auc_score
from matplotlib import pyplot
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import roc_curve, auc
from packaging.version import parse
from sklearn.model_selection import StratifiedKFold
from scipy import interp
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import BernoulliNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.feature_selection import VarianceThreshold, mutual_info_classif, mutual_info_regression
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import ExtraTreesClassifier 
from sklearn.feature_selection import RFE
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
import seaborn as sb
from sklearn.linear_model import Lasso
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn.multiclass import OneVsRestClassifier
from sklearn import svm, datasets
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from collections import Counter
from imblearn.over_sampling import SMOTE
from numpy import where
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold
from sklearn import svm
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix
from collections import Counter
from sklearn.datasets import make_classification
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from imblearn.pipeline import Pipeline
from sklearn.metrics import auc
from sklearn.metrics import RocCurveDisplay
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import AdaBoostClassifier
from sklearn.naive_bayes import ComplementNB
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
# decision tree  on imbalanced dataset with SMOTE oversampling and random undersampling
from numpy import mean
Data=pd.read_csv('data.csv')

X=Data.iloc[: ,3:]

scaler = StandardScaler()
# transform data
X=scaler.fit_transform(X)
y=pd.DataFrame(Data.iloc[:,2]).values.ravel()

y[y==1]=0
y[y==11]=1

X=pd.DataFrame(X)
X.columns = Data.iloc[:,3:].columns




#####################################Feature selection

#Anova

selector = SelectKBest(f_classif, k=100)
X_new = selector.fit_transform(X, y)

##################
#MI
mi = mutual_info_classif(X, y)
mi = pd.Series(mi)
mi.index = X.columns
mi.sort_values(ascending=False, inplace = True)
sel = SelectPercentile(mutual_info_classif, 
  percentile=0.5).fit(X, y)
X.columns[sel.get_support()]
tedad_feature=len(X.columns[sel.get_support()])
X_new = sel.transform(X)
X_new=pd.DataFrame(X_new)

########
sel = ExtraTreesClassifier(n_estimators=2,max_features=1500, random_state=0)
sel.fit(X, y)
sel.feature_importances_  
model = SelectFromModel(sel, prefit=True)
X_new = pd.DataFrame(model.transform(X))


#  LGR
sel = SelectFromModel(LogisticRegression(C =0.08,random_state=0,
penalty = 'l1', solver = 'liblinear'))
sel.fit(X,y)
# print(X.columns[sel.get_support()])
X_new =pd.DataFrame( sel.transform(X))
X_new=X_new .to_numpy()
col_index = sel.get_support()
featurename=(X.columns[col_index])
featurename=pd.DataFrame(featurename)
featurename.to_csv('featurenamesLGR191.csv')  

######
pca = PCA(n_components=100, random_state=42)
pca.fit(X)
X_new = pd.DataFrame(pca.transform(X))
X_new=X_new .to_numpy()

counter = Counter(y)
print(counter)


#scatter plot of examples by class label
X=X.to_numpy()
X_new2=X_new2.to_numpy()

plt.subplot(1,2,1)
for label, _ in counter.items():
 	row_ix = where(y == label)[0]
 	pyplot.scatter(X[row_ix, 0], X[row_ix, 1], label=str(label))
pyplot.legend()
# pyplot.show()
plt.subplot(1,2,2)
for label, _ in counter2.items():
 	row_ix = where(y2 == label)[0]
 	pyplot.scatter(X_new2[row_ix, 0], X_new2[row_ix, 1], label=str(label))
# plt.xlim([-4, 4])
# plt.ylim([-4, 4]) 
pyplot.legend()
pyplot.show()


#######################SMOTE
acc=[]
for i in models:
	
	model =i
	over = SMOTE(sampling_strategy=0.3)
	under = RandomUnderSampler(sampling_strategy=0.5)
	steps = [('over', over), ('under', under), ('model', model)]
	pipeline = Pipeline(steps=steps)
	# evaluate pipeline
	cv =StratifiedKFold(n_splits=5)
	scores = cross_val_score(pipeline, X_new, y, scoring='roc_auc', cv=cv, n_jobs=-1)
	score = mean(scores)
	print('%.1f' % (score *100))
    # acc.append(score)roc_auc accuracy balanced_accuracy
   

############################ AUC


cv = StratifiedKFold(n_splits=5)
# model1 = svm.SVC(kernel="linear", probability=True, random_state=22)
classifier=model13

tprs = []
aucs = []
mean_fpr = np.linspace(0, 1, 100)
# plt.figure(figsize=(10,10))
fig, ax = plt.subplots()
for i, (train, test) in enumerate(cv.split(X_new, y)):
    classifier.fit(X_new[train], y[train])
    viz = RocCurveDisplay.from_estimator(
        classifier,
        X_new[test],
        y[test],
        name="ROC fold {}".format(i),
        alpha=0.8,
        lw=0.9,
        ax=ax,
    )
    interp_tpr = np.interp(mean_fpr, viz.fpr, viz.tpr)
    interp_tpr[0] = 0.0
    tprs.append(interp_tpr)
    aucs.append(viz.roc_auc)

ax.plot([0, 1], [0, 1], linestyle="-", lw=2, color="k", alpha=0.5)

mean_tpr = np.mean(tprs, axis=0)
mean_tpr[-1] = 1.0
mean_auc = auc(mean_fpr, mean_tpr)
std_auc = np.std(aucs)

print(('AUC: %.3f (%.3f)' % (mean_auc, std_auc)))
ax.plot(
    mean_fpr,
    mean_tpr,
    color="b",
    label=r"Mean ROC (AUC = %0.2f $\pm$ %0.2f)" % (mean_auc, std_auc),
    lw=2,
    alpha=0.8,
)

std_tpr = np.std(tprs, axis=0)
tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
ax.fill_between(
    mean_fpr,
    tprs_lower,
    tprs_upper,
    color="grey",
    alpha=0.1,
    #label=r"$\pm$ 1 std.",
)

ax.set(
    xlim=[-0.05, 1.05],
    ylim=[-0.05, 1.05],
    title="LGR feature selection method+MLP classifier ",
)
ax.legend(loc="lower right")
# ax.ylabel('True Positive Rate')
# ax.xlabel('False Positive Rate')
ax.set_ylabel("True Positive Rate")
ax.set_xlabel("False Positive Rate")
plt.savefig('LGR feature selection method+MLP classifier.png',dpi=1200)
plt.show()













############################################ applying oversampling

# X=X.to_numpy()
# X_over=X_over.to_numpy()

# plt.subplot(1,2,1)
# for label, _ in counterx.items():
# 	row_ix = where(y == label)[0]
# 	pyplot.scatter(X[row_ix, 0], X[row_ix, 1], label=str(label))
# pyplot.legend()
# # pyplot.show()
# plt.subplot(1,2,2)
# for label, _ in counter_over.items():
# 	row_ix = where(y_over == label)[0]
# 	pyplot.scatter(X_over[row_ix, 0], X_over[row_ix, 1], label=str(label))
# pyplot.legend()
# pyplot.show()