import sys
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score
from numpy import mean
from numpy import std
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import cross_validate
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score 
from sklearn.metrics import f1_score
from ClassificationMetrics import ClassificationMetrics

# def DT(training_data, training_labels, test_data, test_labels):
#     params = {
#         'max_depth': range(1, 51),
#         'min_samples_split': range(2, 11)
#     }
#     clf = GridSearchCV(DecisionTreeClassifier(), params, n_jobs=-1, cv=1)
#     clf.fit(training_data, training_labels)
#     best_score = clf.best_score_
#     test_score = clf.score(test_data, test_labels)

#     return [best_score,test_score]

# def confusion_matrix_scorer(clf, X, y):
#     y_pred = clf.predict(X)
#     cm = confusion_matrix(y, y_pred)
#     return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}


def DT(data, labels, nof,file,filename,X_External, Y_External):
    params = {
        'max_depth': range(1, 10),
        'min_samples_split': range(2, 11)
    }
    clf = GridSearchCV(DecisionTreeClassifier(), params, n_jobs=-1, cv=nof)
    clf.fit(data, labels)
    best_parameters = clf.best_params_
    md = best_parameters['max_depth']
    mss = best_parameters['min_samples_split']

    model = DecisionTreeClassifier(max_depth=md , min_samples_split=mss)
    # cvs = cross_val_score(model, data, labels, cv=nof)
    # print(cvs)
    # print(cvs.mean() , "\t" , cvs.std())
    r = ClassificationMetrics()
    r.set_predictorName("DT")
    r.set_contin(False)
    r.set_DatasetName(filename)

    bestparameters = 'max_depth= ' +str(md) + ' min_samples_split= '+str(mss)
    r.set_best(bestparameters)
    r.PrintbestParameters()     
    
    cv_results = cross_validate(model, data, labels, cv=nof, scoring=r.confusion_matrix_scorer, return_train_score = True)
    r.Print("DT")
    r.Print("test")
    r.Results("acc" , cv_results['test_acc'])
    r.Results("MCR" , cv_results['test_MisclassificationRate'])
    r.Results("re" , cv_results['test_re'])
    r.Results("Sen" , cv_results['test_Sensitivity'])
    r.Results("pre" , cv_results['test_pre'])
    r.Results("F_S" , cv_results['test_f_sc'])
    # r.Results("Specificity" , cv_results['test_Specificity'])
    # r.Results("roc" , cv_results['test_roc'])
    # r.Results("fpr" , cv_results['test_fpr'])
    # r.Results("tpr" , cv_results['test_tpr'])
    # r.Results("auc" , cv_results['test_auc'])
    r.Print("train")
    r.Results("acc" , cv_results['train_acc'])
    r.Results("MCR" , cv_results['train_MisclassificationRate'])
    r.Results("re" , cv_results['train_re'])
    r.Results("Sen" , cv_results['train_Sensitivity'])
    r.Results("pre" , cv_results['train_pre'])
    r.Results("F_S" , cv_results['train_f_sc'])
    # r.Results("Specificity" , cv_results['train_Specificity'])
    # r.Results("roc" , cv_results['train_roc'])
    # r.Results("fpr" , cv_results['train_fpr'])
    # r.Results("tpr" , cv_results['train_tpr'])
    # r.Results("auc" , cv_results['train_auc'])


    exResult = r.Externalscorer(model, data, labels , X_External, Y_External)
    r.Print("External_test")
    r.PrintExternalResults("acc" , exResult['acc'])
    r.PrintExternalResults("MCR" , exResult['MisclassificationRate'])
    r.PrintExternalResults("re" , exResult['re'])
    r.PrintExternalResults("Sen" , exResult['Sensitivity'])
    r.PrintExternalResults("pre" , exResult['pre'])
    r.PrintExternalResults("F_S" , exResult['f_sc'])

    
# def metricsClassification(tn, fp, fn, tp):
#     Accuracy = (tn + tp ) / (tn+fp+fn+tp)
    # MisclassificationRate = 1-Accuracy
    # MisclassificationRate = (fp+fn) / (tn+fp+fn+tp) 
    # ErrorRate =  MisclassificationRate
    # FalseNegativeRate = fn / (fn+tp)
    # TruePositiveRate = tp / (fn+tp)
    # Sensitivity  = TruePositiveRate
    # Recall = TruePositiveRate
    # FalsePositiveRate= fp / (fp+tn)
    # TrueNegativeRate = tn / (fp+tn)
    # Specificity = TrueNegativeRate
    # Precision = tp / (fp + tp)
    # Prevalence = (fn+tp) / (tn+fp+fn+tp) 


# def metrics(y_true, y_pred):
#     tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
#     ac = accuracy_score(y_true, y_pred)
#     re = recall_score(y_true, y_pred, average=None)
#     pr = precision_score(y_true, y_pred, average=None)
#     fs = f1_score(y_true, y_pred, average=None)
#     metricsClassification(tn, fp, fn, tp)



# def DT2( X ,Y, nof ):
#     KF = KFold(n_splits=nof)
#     for train_index, test_index in KF.split(X):
#         X_train, X_test = X[train_index], X[test_index]
#         Y_train, Y_test = Y[train_index], Y[test_index]   
#         model = DecisionTreeClassifier()
#         model.fit(X_train, Y_train)
#         Y_pred = model.predict(X_test)
#         metrics(Y_test , Y_pred)
#         # CurrentScore.append([model.score(X_train , Y_train) , model.score(X_test, Y_test)])

#     # average = mean(CurrentScore[0]) 
#     # standard = std(CurrentScore[0])
#     # averageTest = mean(CurrentScore[1]) 
#     # standardTest = std(CurrentScore[1])

#     # return [average , standard , averageTest , standardTest]



# def DT2( X ,Y, nof ):
#     KF = KFold(n_splits=nof)
#     CurrentScore = []
#     for train_index, test_index in KF.split(X):
#         X_train, X_test = X[train_index], X[test_index]
#         Y_train, Y_test = Y[train_index], Y[test_index]
                
#         model = DecisionTreeClassifier()
#         model.fit(X_train, Y_train)
        
#         CurrentScore.append([model.score(X_train , Y_train) , model.score(X_test, Y_test)])

#     average = mean(CurrentScore[0]) 
#     standard = std(CurrentScore[0])
#     averageTest = mean(CurrentScore[1]) 
#     standardTest = std(CurrentScore[1])

#     return [average , standard , averageTest , standardTest]

